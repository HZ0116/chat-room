# 💬 联网聊天室

零依赖、纯 Node.js 原生的多人在线聊天室。不依赖任何第三方包，Node.js 内置模块即可运行。

## ✨ 功能

- 🏠 **多房间** — 输入房间号自动创建/加入
- 💬 **实时消息** — WebSocket 全双工通信
- ✍️ **打字提示** — 看到谁正在输入
- 👥 **在线列表** — 实时显示房间成员
- 🔌 **自动重连** — 断线 3 秒后自动恢复
- 🎨 **深色主题** — 现代化 UI，移动端适配

---

## 🚀 本地启动（先试试）

```bash
# 需要 Node.js >= 16，无需 npm install（零依赖）
node chat-server.js

# 浏览器打开 http://localhost:3000
```

---

## 🌐 部署到公网（GitHub + Railway，免费）

> 目标：把链接发给任何人，打开就能聊天。

### 第 1 步：创建 GitHub 仓库

1. 打开 https://github.com → 登录/注册
2. 右上角 `+` → **New repository**
3. 仓库名填 `chat-room`，选 **Public**
4. **不要**勾选 Add README / .gitignore / license（我们已有）
5. 点 **Create repository**

### 第 2 步：上传代码到 GitHub

**不会用 Git 命令行？用网页拖拽：**

1. 进仓库后点 **Add file → Upload files**
2. 把解压后的**整个文件夹内容**拖进去：
   - `chat-server.js`
   - `public/` 文件夹（**整个文件夹**）
   - `package.json`
   - `.gitignore`
3. 底部填 `first commit` → **Commit changes**

**会用 Git？**

```bash
cd chat-room
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/你的用户名/chat-room.git
git push -u origin main
```

### 第 3 步：Railway 一键部署

1. 打开 https://railway.com → 点 **Login with GitHub** 授权
2. 进控制台 → **New Project** → **Deploy from GitHub repo**
3. 选刚建的 `chat-room` 仓库 → 确认
4. Railway 自动识别 Node.js → 安装依赖 → 启动 `npm start`
5. 等 1~2 分钟，看到绿色 ✅ 就是部署成功

### 第 4 步：拿到公网地址

1. 点服务卡片 → **Settings** 标签
2. 左侧菜单 **Networking** → 点 **Generate Domain**
3. 得到一个地址，类似：
   ```
   https://chat-room-production.up.railway.app
   ```
4. 打开这个地址 → 输入昵称和房间号 → 进入聊天室 🎉

**把这个链接发给朋友，他们打开后输入相同房间号，就能和你实时聊天了！**

---

## 🔄 以后怎么更新代码

改完代码后：

- **网页方式**：在 GitHub 仓库里点文件 → 编辑 → Commit
- **Git 方式**：`git add . && git commit -m "更新" && git push`

Railway 会自动检测 GitHub 变动，**自动重新部署**，无需手动操作。

---

## 🛠️ 常见问题

| 问题 | 原因 | 解决 |
|---|---|---|
| 部署成功但打不开 | 端口没读 `process.env.PORT` | 已修复，确保用本仓库最新代码 |
| WebSocket 连不上 | 前端地址写死 localhost | 已修复，前端自动取当前域名 |
| Railway 部署失败 | `package.json` 缺 start 脚本 | 已包含 `"start": "node chat-server.js"` |
| 免费额度用完 | 超过 Railway 试用额度 | 项目休眠，访问时自动唤醒（有几秒延迟） |

---

## 📁 文件结构

```
chat-room/
├── chat-server.js      # 后端（零依赖 WebSocket 服务器）
├── public/
│   └── index.html      # 前端聊天页面
├── package.json        # 项目配置（含 start 脚本）
├── .gitignore          # 忽略 node_modules
└── README.md           # 本文件
```

## 🔧 技术栈

- **后端**：Node.js 原生 `http` + 手写 WebSocket 协议（RFC 6455）
- **前端**：原生 HTML/CSS/JS（无框架）
- **部署**：GitHub + Railway（免费）

## License

MIT